package com.retete.retete_culinare.service;

import com.retete.retete_culinare.model.Ustensila;
import com.retete.retete_culinare.repository.UstensilaRepository;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class UstensilaServiceTest {

    @InjectMocks
    private UstensilaService ustensilaService;

    @Mock
    private UstensilaRepository ustensilaRepository;

    private Ustensila ustensila;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ustensila = new Ustensila();
        ustensila.setNume("Lingura");
        ustensila.setCategorie("Utensil");
    }

    @Test
    public void testGasesteUstensilaDupaId() {
        when(ustensilaRepository.findById(1L)).thenReturn(Optional.of(ustensila));
        Ustensila foundUstensila = ustensilaService.gasesteDupaId(1L);
        assertNotNull(foundUstensila);
        assertEquals(ustensila.getId(), foundUstensila.getId());
    }

    @Test
    public void testGasesteUstensilaDupaIdThrowsException() {
        when(ustensilaRepository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(EntityNotFoundException.class, () -> ustensilaService.gasesteDupaId(1L));
    }

    @Test
    public void testGasesteUstensileDupaRetetaId() {
        when(ustensilaRepository.findByRetetaId(1L)).thenReturn(Collections.singletonList(ustensila));
        List<Ustensila> ustensile = ustensilaService.gasesteUstensileDupaRetetaId(1L);
        assertNotNull(ustensile);
        assertEquals(1, ustensile.size());
        assertEquals(ustensila, ustensile.get(0));
    }
}
