package com.retete.retete_culinare.service;

import com.retete.retete_culinare.model.Etapa;
import com.retete.retete_culinare.repository.EtapaRepository;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class EtapaServiceTest {

    @InjectMocks
    private EtapaService etapaService;

    @Mock
    private EtapaRepository etapaRepository;

    private Etapa etapa;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        etapa = new Etapa();
        etapa.setId(1L);
        etapa.setNume("Pregătire");
        etapa.setTimp("30 min");
        etapa.setDescriere("Se pregătește ingredientul.");
    }

    @Test
    public void testSalveazaEtapa() {
        when(etapaRepository.save(any(Etapa.class))).thenReturn(etapa);

        etapaService.salveazaEtapa(etapa);

        verify(etapaRepository, times(1)).save(etapa);
    }

    @Test
    public void testGasesteEtapeDupaRetetaId() {
        when(etapaRepository.findByRetetaId(1L)).thenReturn(Collections.singletonList(etapa));

        List<Etapa> etape = etapaService.gasesteEtapeDupaRetetaId(1L);

        assertNotNull(etape);
        assertEquals(1, etape.size());
        assertEquals(etapa, etape.get(0));
    }

    @Test
    public void testGasesteDupaId() {
        when(etapaRepository.findById(1L)).thenReturn(Optional.of(etapa));

        Etapa etapaGasita = etapaService.gasesteDupaId(1L);

        assertNotNull(etapaGasita);
        assertEquals(etapa.getId(), etapaGasita.getId());
        assertEquals(etapa.getNume(), etapaGasita.getNume());
    }

    @Test
    public void testGasesteDupaId_EntityNotFoundException() {
        when(etapaRepository.findById(1L)).thenReturn(Optional.empty());

        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {
            etapaService.gasesteDupaId(1L);
        });

        assertEquals("Etapa cu ID 1 nu a fost găsită.", exception.getMessage());
    }

    @Test
    public void testUpdateEtapa() {
        when(etapaRepository.findById(1L)).thenReturn(Optional.of(etapa));
        Etapa etapaActualizata = new Etapa();
        etapaActualizata.setNume("Noua etapă");
        etapaActualizata.setTimp("45 min");
        etapaActualizata.setDescriere("Se adaugă ingrediente noi.");

        etapaService.updateEtapa(1L, etapaActualizata);

        verify(etapaRepository, times(1)).save(etapa);
        assertEquals("Noua etapă", etapa.getNume());
        assertEquals("45 min", etapa.getTimp());
        assertEquals("Se adaugă ingrediente noi.", etapa.getDescriere());
    }
}
