package com.retete.retete_culinare.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class RetetaTest {

    private Reteta reteta;

    @BeforeEach
    public void setUp() {
        reteta = new Reteta();
    }

    @Test
    public void testGetterAndSetterForNume() {
        String numeTest = "Mancare de porc";
        reteta.setNume(numeTest);

        assertEquals(numeTest, reteta.getNume(), "Getter-ul pentru nume nu returnează valoarea corectă!");
    }

    @Test
    public void testGetterAndSetterForCategorie() {
        String categorieTest = "Fel principal";
        reteta.setCategorie(categorieTest);

        assertEquals(categorieTest, reteta.getCategorie(), "Getter-ul pentru categorie nu returnează valoarea corectă!");
    }

    @Test
    public void testGetterAndSetterForCost() {
        Double costTest = 50.0;
        reteta.setCost(costTest);

        assertEquals(costTest, reteta.getCost(), "Getter-ul pentru cost nu returnează valoarea corectă!");
    }

    @Test
    public void testGetterAndSetterForTimpPreparare() {
        Integer timpTest = 30;
        reteta.setTimpPreparare(timpTest);

        assertEquals(timpTest, reteta.getTimpPreparare(), "Getter-ul pentru timp preparare nu returnează valoarea corectă!");
    }
}
