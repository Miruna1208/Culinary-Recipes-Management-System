package com.retete.retete_culinare.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class EtapaTest {

    @Test
    void testGetterSetterNume() {
        Etapa etapa = new Etapa();

        etapa.setNume("Preparare");

        assertEquals("Preparare", etapa.getNume());
    }

    @Test
    void testGetterSetterTimp() {
        Etapa etapa = new Etapa();

        etapa.setTimp("30 minute");

        assertEquals("30 minute", etapa.getTimp());
    }
}
