package com.retete.retete_culinare.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class UstensilaTest {

    private Ustensila ustensila;

    @BeforeEach
    public void setUp() {
        ustensila = new Ustensila();
    }

    @Test
    public void testGetterAndSetterForNume() {
        String numeTest = "Tigaie";
        ustensila.setNume(numeTest);

        assertEquals(numeTest, ustensila.getNume(), "Getter-ul pentru nume nu returnează valoarea corectă!");
    }

    @Test
    public void testGetterAndSetterForCategorie() {
        String categorieTest = "Vas de gătit";
        ustensila.setCategorie(categorieTest);

        assertEquals(categorieTest, ustensila.getCategorie(), "Getter-ul pentru categorie nu returnează valoarea corectă!");
    }

    @Test
    public void testGetterAndSetterForId() {
        Long idTest = 1L;
        ustensila.setId(idTest);

        assertEquals(idTest, ustensila.getId(), "Getter-ul pentru id nu returnează valoarea corectă!");
    }

}
