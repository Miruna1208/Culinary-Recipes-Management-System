package com.retete.retete_culinare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReteteCulinareApplicationTests {

	@Test
	void contextLoads() {
	}

}
