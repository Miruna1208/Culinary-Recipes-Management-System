package com.retete.retete_culinare.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class IngredientTest {

    private Ingredient ingredient;

    @BeforeEach
    public void setUp() {
        ingredient = new Ingredient();
    }

    @Test
    public void testGetterAndSetterForNume() {
        String numeTest = "Roșii";
        ingredient.setNume(numeTest);

        assertEquals(numeTest, ingredient.getNume(), "Getter-ul pentru nume nu returnează valoarea corectă!");
    }

    @Test
    public void testGetterAndSetterForCategorie() {
        String categorieTest = "Legume";
        ingredient.setCategorie(categorieTest);

        assertEquals(categorieTest, ingredient.getCategorie(), "Getter-ul pentru categorie nu returnează valoarea corectă!");
    }

    @Test
    public void testGetterAndSetterForCantitate() {
        double cantitateTest = 5.0;
        ingredient.setCantitate(cantitateTest);

        assertEquals(cantitateTest, ingredient.getCantitate(), "Getter-ul pentru cantitate nu returnează valoarea corectă!");
    }

    @Test
    public void testGetterAndSetterForUnitateMasura() {
        String unitateMasuraTest = "kg";
        ingredient.setUnitateMasura(unitateMasuraTest);

        assertEquals(unitateMasuraTest, ingredient.getUnitateMasura(), "Getter-ul pentru unitate masura nu returnează valoarea corectă!");
    }

    @Test
    public void testGetterAndSetterForPretProdus() {
        double pretProdusTest = 20.0;
        ingredient.setPretProdus(pretProdusTest);

        assertEquals(pretProdusTest, ingredient.getPretProdus(), "Getter-ul pentru pret produs nu returnează valoarea corectă!");
    }

    @Test
    public void testGetterAndSetterForPretTotal() {
        double pretTotalTest = 100.0;
        ingredient.setPretTotal(pretTotalTest);

        assertEquals(pretTotalTest, ingredient.getPretTotal(), "Getter-ul pentru pret total nu returnează valoarea corectă!");
    }
}
