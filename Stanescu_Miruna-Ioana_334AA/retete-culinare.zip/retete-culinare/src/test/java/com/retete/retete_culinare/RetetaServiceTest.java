package com.retete.retete_culinare.service;

import com.retete.retete_culinare.model.Reteta;
import com.retete.retete_culinare.repository.RetetaRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class RetetaServiceTest {

    @InjectMocks
    private RetetaService retetaService;

    @Mock
    private RetetaRepository retetaRepository;

    @Mock
    private EntityManager entityManager;

    private Reteta reteta;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        reteta = new Reteta("Supa", "Ciorbe", "supa.jpg");
    }

    @Test
    public void testSalveazaReteta() {
        when(retetaRepository.save(any(Reteta.class))).thenReturn(reteta);
        Reteta savedReteta = retetaService.salveazaReteta(reteta);
        assertNotNull(savedReteta);
        assertEquals(reteta.getNume(), savedReteta.getNume());
    }

    @Test
    public void testGetAllRetete() {
        when(retetaRepository.findAll()).thenReturn(Collections.singletonList(reteta));
        List<Reteta> retete = retetaService.getAllRetete();
        assertNotNull(retete);
        assertEquals(1, retete.size());
        assertEquals(reteta, retete.get(0));
    }

    @Test
    public void testGasesteRetetaDupaId() {
        when(retetaRepository.findById(1L)).thenReturn(Optional.of(reteta));
        Reteta foundReteta = retetaService.gasesteRetetaDupaId(1L);
        assertNotNull(foundReteta);
        assertEquals(reteta.getId(), foundReteta.getId());
    }

    @Test
    public void testGasesteRetetaDupaIdReturnsNull() {
        when(retetaRepository.findById(1L)).thenReturn(Optional.empty());
        Reteta foundReteta = retetaService.gasesteRetetaDupaId(1L);
        assertNull(foundReteta);
    }

    @Test
    public void testStergeReteta() {
        doNothing().when(retetaRepository).deleteById(1L);
        retetaService.stergeReteta(1L);
        verify(retetaRepository, times(1)).deleteById(1L);
    }

    @Test
    public void testUpdateReteta() {
        when(retetaRepository.save(any(Reteta.class))).thenReturn(reteta);
        reteta.setNume("Supa de pui");
        retetaService.updateReteta(1L, reteta);
        verify(retetaRepository, times(1)).save(reteta);
    }

    @Test
    public void testFindAll() {
        String hql = "FROM Reteta";
        Query query = mock(Query.class);
        when(entityManager.createQuery(hql)).thenReturn(query);
        when(query.getResultList()).thenReturn(Collections.singletonList(reteta));
        List<Reteta> retete = retetaService.findAll();
        assertNotNull(retete);
        assertEquals(1, retete.size());
    }
}
