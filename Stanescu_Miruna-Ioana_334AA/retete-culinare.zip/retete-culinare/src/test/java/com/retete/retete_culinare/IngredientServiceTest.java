package com.retete.retete_culinare.service;

import com.retete.retete_culinare.model.Ingredient;
import com.retete.retete_culinare.repository.IngredientRepository;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class IngredientServiceTest {

    @InjectMocks
    private IngredientService ingredientService;

    @Mock
    private IngredientRepository ingredientRepository;

    private Ingredient ingredient;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ingredient = new Ingredient();
        ingredient.setId(1L);
        ingredient.setNume("Zahăr");
        ingredient.setCategorie("Dulciuri");
        ingredient.setCantitate(500.0);
        ingredient.setUnitateMasura("g");
        ingredient.setPretProdus(10.0);
        ingredient.setPretTotal(10.0);
    }

    @Test
    public void testSalveazaIngredient() {
        when(ingredientRepository.save(any(Ingredient.class))).thenReturn(ingredient);
        ingredientService.salveazaIngredient(ingredient);
        verify(ingredientRepository, times(1)).save(ingredient);
    }

    @Test
    public void testGasesteIngredienteDupaRetetaId() {
        when(ingredientRepository.findByRetetaId(1L)).thenReturn(Collections.singletonList(ingredient));
        List<Ingredient> ingrediente = ingredientService.gasesteIngredienteDupaRetetaId(1L);
        assertNotNull(ingrediente);
        assertEquals(1, ingrediente.size());
        assertEquals(ingredient, ingrediente.get(0));
    }

    @Test
    public void testGasesteDupaId() {
        when(ingredientRepository.findById(1L)).thenReturn(Optional.of(ingredient));
        Ingredient foundIngredient = ingredientService.gasesteDupaId(1L);
        assertNotNull(foundIngredient);
        assertEquals(ingredient.getId(), foundIngredient.getId());
    }

    @Test
    public void testGasesteDupaIdThrowsException() {
        when(ingredientRepository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(EntityNotFoundException.class, () -> ingredientService.gasesteDupaId(1L));
    }

    @Test
    public void testUpdateIngredient() {
        when(ingredientRepository.findById(1L)).thenReturn(Optional.of(ingredient));
        when(ingredientRepository.save(any(Ingredient.class))).thenReturn(ingredient);

        ingredient.setNume("Miere");
        ingredientService.updateIngredient(1L, ingredient);
        verify(ingredientRepository, times(1)).save(ingredient);
    }
}
