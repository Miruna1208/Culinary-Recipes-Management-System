package com.retete.retete_culinare.controller;

import com.retete.retete_culinare.model.Etapa;
import com.retete.retete_culinare.model.Ingredient;
import com.retete.retete_culinare.model.Reteta;
import com.retete.retete_culinare.model.Ustensila;
import com.retete.retete_culinare.service.EtapaService;
import com.retete.retete_culinare.service.IngredientService;
import com.retete.retete_culinare.service.RetetaService;
import com.retete.retete_culinare.service.UstensilaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class PaginaPrincipalaController {

    @Autowired
    private RetetaService retetaService;

    @Autowired
    private IngredientService ingredientService;

    @Autowired
    private EtapaService etapaService;

    @Autowired
    private UstensilaService ustensilaService;

    @GetMapping("/")
    public String index() {
        return "index";
    }
    @GetMapping("/retete")
    public String showRetete(Model model) {
        List<Reteta> retete = retetaService.getAllRetete();
        model.addAttribute("retete", retete);
        return "retete";
    }

    @GetMapping("/adauga-reteta-page")
    public String adaugaReteta() {
        return "adauga-reteta-page";
    }

    @PostMapping("/adauga-reteta")
    public String adaugaRetetaPost(@RequestParam String nume, @RequestParam String categorie, Model model) {
        if (!nume.matches("^[a-zA-Z]+( [a-zA-Z]+)*$")) {
            model.addAttribute("errorNume", "Introduceti un nume valid!");
            model.addAttribute("nume", nume);
            model.addAttribute("categorie", categorie);
            return "adauga-reteta-page";
        }

        List<String> categoriiPermise = List.of("Mic-dejun", "Pranz", "Aperitiv", "Cina", "Desert");

        if (!categoriiPermise.contains(categorie)) {
            model.addAttribute("errorCategorie", "Categoria introdusă nu este validă! Te rugăm să alegi din următoarele opțiuni: Mic-dejun, Pranz, Aperitiv, Cina, Desert.");
            model.addAttribute("categorie", categorie);
            model.addAttribute("nume", nume);
            return "adauga-reteta-page";
        }

        Reteta reteta = new Reteta();
        reteta.setNume(nume);
        reteta.setCategorie(categorie);

        retetaService.salveazaReteta(reteta);

        model.addAttribute("retetaId", reteta.getId());

        return "redirect:/ingrediente?retetaId=" + reteta.getId();
    }

    @GetMapping("/stergere-reteta")
    public String stergeReteta() {
        return "stergere-reteta";
    }

    @GetMapping("/adauga-ingredient")
    public String adaugaIngredientePage(@RequestParam Long retetaId, Model model) {
        Reteta reteta = retetaService.gasesteRetetaDupaId(retetaId);

        model.addAttribute("reteta", reteta);
        return "ingrediente";
    }

    @PostMapping("/adauga-ingredient")
    public String adaugaIngredientPost(@RequestParam String nume,
                                       @RequestParam String categorie,
                                       @RequestParam String cantitate,
                                       @RequestParam String unitateMasura,
                                       @RequestParam String pretProdus,
                                       @RequestParam Long retetaId,
                                       RedirectAttributes redirectAttributes) {

        Reteta reteta = retetaService.gasesteRetetaDupaId(retetaId);

        if (!nume.matches("^[a-zA-Z]+( [a-zA-Z]+)*$")) {
            redirectAttributes.addFlashAttribute("errorNume", "Introduceți un nume valid!");
            redirectAttributes.addFlashAttribute("nume", nume);
            redirectAttributes.addFlashAttribute("categorie", categorie);
            redirectAttributes.addFlashAttribute("cantitate", cantitate);
            redirectAttributes.addFlashAttribute("unitateMasura", unitateMasura);
            redirectAttributes.addFlashAttribute("pretProdus", pretProdus);
            return "redirect:/ingrediente?retetaId=" + retetaId;
        }

        List<String> categoriiIngrediente = List.of(
                "Legume", "Fructe", "Lactate", "Carne", "Peste", "Cereale",
                "Condimente", "Uleiuri si grasimi", "Nuci si seminte",
                "Dulciuri", "Panificatie", "Bauturi", "Sosuri",
                "Alte ingrediente"
        );

        if (!categoriiIngrediente.contains(categorie)) {
            redirectAttributes.addFlashAttribute("errorCategorie", "Categoria introdusă nu este validă! Te rugăm să alegi din următoarele opțiuni: Legume, Fructe, Lactate, Carne, Peste, Cereale, Condimente, Uleiuri si grasimi, Nuci și seminte, Dulciuri, Panificatie, Sosuri, Alte ingrediente.");
            redirectAttributes.addFlashAttribute("nume", nume);
            redirectAttributes.addFlashAttribute("categorie", categorie);
            redirectAttributes.addFlashAttribute("cantitate", cantitate);
            redirectAttributes.addFlashAttribute("unitateMasura", unitateMasura);
            redirectAttributes.addFlashAttribute("pretProdus", pretProdus);
            return "redirect:/ingrediente?retetaId=" + retetaId;
        }


        if (!cantitate.matches("^[1-9]\\d*$")) {
            redirectAttributes.addFlashAttribute("errorCantitate", "Cantitatea trebuie să fie un număr.");
            redirectAttributes.addFlashAttribute("nume", nume);
            redirectAttributes.addFlashAttribute("categorie", categorie);
            redirectAttributes.addFlashAttribute("cantitate", cantitate);
            redirectAttributes.addFlashAttribute("unitateMasura", unitateMasura);
            redirectAttributes.addFlashAttribute("pretProdus", pretProdus);
            return "redirect:/ingrediente?retetaId=" + retetaId;
        }
        int cantitateValoare = Integer.parseInt(cantitate);

        List<String> categoriiUnitateMasura = List.of("Bucata", "Grame", "Mililitri");

        if (!categoriiUnitateMasura.contains(unitateMasura)) {
            redirectAttributes.addFlashAttribute("errorUnitateMasura", "Unitatea de măsură introdusă nu este validă! Te rugăm să alegi din următoarele opțiuni:Bucata, Grame, Mililitri.");
            redirectAttributes.addFlashAttribute("nume", nume);
            redirectAttributes.addFlashAttribute("categorie", categorie);
            redirectAttributes.addFlashAttribute("cantitate", cantitate);
            redirectAttributes.addFlashAttribute("unitateMasura", unitateMasura);
            redirectAttributes.addFlashAttribute("pretProdus", pretProdus);
            return "redirect:/ingrediente?retetaId=" + retetaId;
        }

        if (!pretProdus.matches("^[0-9]+(\\.[0-9]+)?$")) {
            redirectAttributes.addFlashAttribute("errorPret", "Prețul trebuie să fie un număr.");
            redirectAttributes.addFlashAttribute("nume", nume);
            redirectAttributes.addFlashAttribute("categorie", categorie);
            redirectAttributes.addFlashAttribute("cantitate", cantitate);
            redirectAttributes.addFlashAttribute("unitateMasura", unitateMasura);
            redirectAttributes.addFlashAttribute("pretProdus", pretProdus);
            return "redirect:/ingrediente?retetaId=" + retetaId;
        }
        double pretProdusValoare = Double.parseDouble(pretProdus);

        double pretTotal;

      if(unitateMasura.matches("Grame") || unitateMasura.matches("Mililitri"))
        pretTotal = cantitateValoare * 0.001 * pretProdusValoare;
      else
          pretTotal = cantitateValoare * pretProdusValoare;

        Ingredient ingredient = new Ingredient();
        ingredient.setNume(nume);
        ingredient.setCategorie(categorie);
        ingredient.setCantitate(cantitateValoare);
        ingredient.setUnitateMasura(unitateMasura);
        ingredient.setPretProdus(pretProdusValoare);
        ingredient.setPretTotal(pretTotal);
        ingredient.setReteta(reteta);

        ingredientService.salveazaIngredient(ingredient);

        List<Ingredient> ingrediente = ingredientService.gasesteIngredienteDupaRetetaId(retetaId);
        double costTotal = 0;
        for (Ingredient ing : ingrediente) {
            costTotal += ing.getPretTotal();
        }
        reteta.setCost(costTotal);
        retetaService.salveazaReteta(reteta);

        return "redirect:/ingrediente?retetaId=" + retetaId;
    }


    @GetMapping("/ingrediente")
    public String paginaIngrediente(@RequestParam Long retetaId, Model model) {
        Reteta reteta = retetaService.gasesteRetetaDupaId(retetaId);

        List<Ingredient> ingrediente = ingredientService.gasesteIngredienteDupaRetetaId(retetaId);
        model.addAttribute("ingrediente", ingrediente);
        model.addAttribute("reteta", reteta);

        return "ingrediente";
    }

    @GetMapping("/adauga-etapa")
    public String adaugaEtapaPage(@RequestParam Long retetaId, Model model) {
        Reteta reteta = retetaService.gasesteRetetaDupaId(retetaId);

        model.addAttribute("reteta", reteta);
        return "etape";
    }

    @PostMapping("/adauga-etapa")
    public String adaugaEtapaPost(@RequestParam String nume,
                                  @RequestParam String timp,
                                  @RequestParam String descriere,
                                  @RequestParam Long retetaId,
                                  RedirectAttributes redirectAttributes) {

        Reteta reteta = retetaService.gasesteRetetaDupaId(retetaId);

        if (!nume.matches("^[a-zA-Z]+( [a-zA-Z]+)*$")) {
            redirectAttributes.addFlashAttribute("errorNume", "Introduceți un nume valid!");
            redirectAttributes.addFlashAttribute("nume", nume);
            redirectAttributes.addFlashAttribute("timp", timp);
            return "redirect:/etape?retetaId=" + retetaId;
        }

        if (!timp.matches("^[1-9]\\d*$")) {
            redirectAttributes.addFlashAttribute("errorTimp", "Timpul trebuie să fie un număr.");
            redirectAttributes.addFlashAttribute("nume", nume);
            redirectAttributes.addFlashAttribute("timp", timp);
            return "redirect:/etape?retetaId=" + retetaId;
        }
        int timpValoare = Integer.parseInt(timp);


        Etapa etapa = new Etapa();
        etapa.setNume(nume);
        etapa.setTimp(timp);
        etapa.setDescriere(descriere);
        etapa.setReteta(reteta);

        etapaService.salveazaEtapa(etapa);

        List<Etapa> etape = etapaService.gasesteEtapeDupaRetetaId(retetaId);
        int timpTotal = 0;
        for (Etapa e : etape) {
            timpTotal += Integer.parseInt(e.getTimp());
        }

        reteta.setTimpPreparare(timpTotal);
        retetaService.salveazaReteta(reteta);

        return "redirect:/etape?retetaId=" + retetaId;
    }

    @GetMapping("/etape")
    public String paginaEtape(@RequestParam Long retetaId, Model model) {
        Reteta reteta = retetaService.gasesteRetetaDupaId(retetaId);

        List<Etapa> etape = etapaService.gasesteEtapeDupaRetetaId(retetaId);
        model.addAttribute("etape", etape);
        model.addAttribute("reteta", reteta);

        return "etape";
    }

    @GetMapping("/adauga-ustensila")
    public String adaugaUstensilaPage(@RequestParam Long retetaId, Model model) {
        Reteta reteta = retetaService.gasesteRetetaDupaId(retetaId);
        model.addAttribute("reteta", reteta);
        return "ustensile";
    }

    @PostMapping("/adauga-ustensila")
    public String adaugaUstensilaPost(@RequestParam String nume,
                                      @RequestParam String categorie,
                                      @RequestParam Long retetaId,
                                      RedirectAttributes redirectAttributes) {

        Reteta reteta = retetaService.gasesteRetetaDupaId(retetaId);

        if (!nume.matches("^[a-zA-Z]+( [a-zA-Z]+)*$")) {
            redirectAttributes.addFlashAttribute("errorNume", "Introduceți un nume valid!");
            redirectAttributes.addFlashAttribute("nume", nume);
            redirectAttributes.addFlashAttribute("categorie", categorie);
            return "redirect:/ustensile?retetaId=" + retetaId;
        }

        List<String> categoriiUstensile = List.of(
                "Vase",
                "Instrumente",
                "Ustensile",
                "Masurare",
                "Gratare",
                "Electrocasnice",
                "Recipiente",
                "Coacere",
                "Decorat"
        );

        if (!categoriiUstensile.contains(categorie)) {
            redirectAttributes.addFlashAttribute("errorCategorie",
                    "Categoria introdusa nu este valida! Te rugam sa alegi din urmatoarele optiuni: " +
                            "Vase, Instrumente, Ustensile, Masurare, Gratare, Electrocasnice, " +
                            "Recipiente, Coacere, Decorat.");
            redirectAttributes.addFlashAttribute("nume", nume);
            redirectAttributes.addFlashAttribute("categorie", categorie);
            return "redirect:/ustensile?retetaId=" + retetaId;
        }

        Ustensila ustensila = new Ustensila();
        ustensila.setNume(nume);
        ustensila.setCategorie(categorie);
        ustensila.setReteta(reteta);

        ustensilaService.salveazaUstensila(ustensila);

        return "redirect:/ustensile?retetaId=" + retetaId;
    }

    @GetMapping("/ustensile")
    public String paginaUstensile(@RequestParam Long retetaId, Model model) {
        Reteta reteta = retetaService.gasesteRetetaDupaId(retetaId);

        List<Ustensila> ustensile = ustensilaService.gasesteUstensileDupaRetetaId(retetaId);
        model.addAttribute("ustensile", ustensile);
        model.addAttribute("reteta", reteta);

        return "ustensile";
    }

    @GetMapping("/stergere-reteta/{id}")
    public String confirmDelete(@PathVariable Long id, Model model) {
        Reteta reteta = retetaService.gasesteRetetaDupaId(id);
        model.addAttribute("reteta", reteta);
        return "stergere-reteta";
    }

    @PostMapping("/stergere-reteta/{id}")
    public String deleteRecipe(@PathVariable Long id) {
        retetaService.stergeReteta(id);
        return "redirect:/retete";
    }

    @GetMapping("/modifica-reteta/{id}")
    public String modificaRetetaForm(@PathVariable Long id, Model model) {
        Reteta reteta = retetaService.gasesteRetetaDupaId(id);

        model.addAttribute("reteta", reteta);

        model.addAttribute("errorNume", model.getAttribute("errorNume"));
        model.addAttribute("errorCategorie", model.getAttribute("errorCategorie"));
        model.addAttribute("errorTimpPreparare", model.getAttribute("errorTimpPreparare"));

        return "modifica-reteta";
    }

    @PostMapping("/modifica-reteta/{id}")
    public String modificaReteta(@PathVariable Long id,
                                 @RequestParam String nume,
                                 @RequestParam String categorie,
                                 RedirectAttributes redirectAttributes) {

        if (!nume.matches("^[a-zA-Z]+( [a-zA-Z]+)*$")) {
            redirectAttributes.addFlashAttribute("errorNume", "Introduceți un nume valid pentru rețetă!");
            return "redirect:/modifica-reteta/" + id;
        }

        List<String> categoriiValide = List.of("Mic-dejun", "Pranz", "Aperitiv", "Cina", "Desert");
        if (!categoriiValide.contains(categorie)) {
            redirectAttributes.addFlashAttribute("errorCategorie", "Categoria introdusă nu este validă! Te rugăm să alegi din următoarele opțiuni: Mic-dejun, Pranz, Aperitiv, Cina, Desert.");
            return "redirect:/modifica-reteta/" + id;
        }

        Reteta reteta = retetaService.gasesteRetetaDupaId(id);
        reteta.setNume(nume);
        reteta.setCategorie(categorie);

        retetaService.updateReteta(id, reteta);

        return "redirect:/modifica-reteta/" + id;
    }

    @PostMapping("/modifica-ingredient/{id}")
    public String modificaIngredient(@PathVariable Long id,
                                     @RequestParam Long idReteta,
                                     @RequestParam String nume,
                                     @RequestParam String categorie,
                                     @RequestParam String cantitate,
                                     @RequestParam String unitateMasura,
                                     @RequestParam String pretProdus,
                                     RedirectAttributes redirectAttributes) {

        Reteta reteta = retetaService.gasesteRetetaDupaId(idReteta);

        if (!nume.matches("^[a-zA-Z]+( [a-zA-Z]+)*$")) {
            redirectAttributes.addFlashAttribute("errorNume", "Introduceți un nume valid pentru ingredient!");
            return "redirect:/modifica-reteta/" + idReteta;
        }

        List<String> categoriiValide = List.of(
                "Legume", "Fructe", "Lactate", "Carne", "Peste", "Cereale",
                "Condimente", "Uleiuri și grasimi", "Nuci si semințe",
                "Dulciuri", "Panificatie", "Bauturi", "Sosuri",
                "Alte ingrediente");
        if (!categoriiValide.contains(categorie)) {
            redirectAttributes.addFlashAttribute("errorCategorie", "Categoria introdusă nu este validă! Te rugăm să alegi din următoarele opțiuni: Legume, Fructe, Lactate, Carne, Peste, Cereale, Condimente, Uleiuri si grasimi, Nuci și semințe, Dulciuri, Panificatie, Sosuri, Alte ingrediente.");
            return "redirect:/modifica-reteta/" + idReteta;
        }

        if (!cantitate.matches("^[0-9]+(\\.[0-9]+)?$")) {
            redirectAttributes.addFlashAttribute("errorCantitate", "Cantitatea trebuie să fie un număr pozitiv.");
            return "redirect:/modifica-reteta/" + idReteta;
        }
        double cantitateValoare = Double.parseDouble(cantitate);

        List<String> unitatiValide = List.of("Bucata", "Grame", "Mililitri");
        if (!unitatiValide.contains(unitateMasura)) {
            redirectAttributes.addFlashAttribute("errorUnitateMasura", "Unitatea de măsură trebuie să fie Bucata, Grame sau Mililitri.");
            return "redirect:/modifica-reteta/" + idReteta;
        }

        if (!pretProdus.matches("^[0-9]+(\\.[0-9]+)?$")) {
            redirectAttributes.addFlashAttribute("errorPret", "Prețul trebuie să fie un număr.");
            return "redirect:/ingrediente?retetaId=" + idReteta;
        }
        double pretProdusValoare = Double.parseDouble(pretProdus);

        double pretTotal;
        if(!unitateMasura.matches("Bucata"))
            pretTotal = cantitateValoare * 0.001 * pretProdusValoare;
        else
            pretTotal = cantitateValoare * pretProdusValoare;

        List<Ingredient> ingrediente = ingredientService.gasesteIngredienteDupaRetetaId(idReteta);
        double costTotal = 0;
        for (Ingredient ing : ingrediente) {
            costTotal += ing.getPretTotal();
        }
        reteta.setCost(costTotal);
        retetaService.salveazaReteta(reteta);

        Ingredient ingredient = ingredientService.gasesteDupaId(id);
        ingredient.setNume(nume);
        ingredient.setCategorie(categorie);
        ingredient.setCantitate(cantitateValoare);
        ingredient.setUnitateMasura(unitateMasura);
        ingredient.setPretProdus(pretProdusValoare);
        ingredient.setPretTotal(pretTotal);
        ingredientService.updateIngredient(id, ingredient);

        return "redirect:/modifica-reteta/" + idReteta;
    }

    @PostMapping("/modifica-etapa/{id}")
    public String modificaEtapa(@PathVariable Long id,
                                @RequestParam Long idReteta,
                                @RequestParam String nume,
                                @RequestParam String timp,
                                @RequestParam String descriere,
                                RedirectAttributes redirectAttributes) {

        Reteta reteta = retetaService.gasesteRetetaDupaId(idReteta);

        if (!nume.matches("^[a-zA-Z ]+$")) {
            redirectAttributes.addFlashAttribute("errorNumeEtapa", "Introduceți un nume valid pentru etapă!");
            return "redirect:/modifica-reteta/" + idReteta;
        }

        if (!timp.matches("^[1-9]\\d*$")) {
            redirectAttributes.addFlashAttribute("errorTimp", "Timpul trebuie să fie un număr pozitiv.");
            return "redirect:/modifica-reteta/" + idReteta;
        }
        int timpValoare = Integer.parseInt(timp);

        Etapa etapa = etapaService.gasesteDupaId(id);
        etapa.setNume(nume);
        etapa.setTimp(timp);
        etapa.setDescriere(descriere);
        etapaService.updateEtapa(id, etapa);

        List<Etapa> etape = etapaService.gasesteEtapeDupaRetetaId(idReteta);
        int timpTotal = 0;
        for (Etapa e : etape) {
            timpTotal += Integer.parseInt(e.getTimp());
        }

        reteta.setTimpPreparare(timpTotal);
        retetaService.salveazaReteta(reteta);

        return "redirect:/modifica-reteta/" + idReteta;
    }

    @PostMapping("/modifica-ustensila/{id}")
    public String modificaUstensila(@PathVariable Long id,
                                    @RequestParam Long idReteta,
                                    @RequestParam String nume,
                                    @RequestParam String categorie,
                                    RedirectAttributes redirectAttributes) {

        if (!nume.matches("^[a-zA-Z ]+$")) {
            redirectAttributes.addFlashAttribute("errorNumeUstensila", "Introduceți un nume valid pentru ustensilă!");
            return "redirect:/modifica-reteta/" + idReteta;
        }

        if (!categorie.matches("^[a-zA-Z ]+$")) {
            redirectAttributes.addFlashAttribute("errorCategorieUstensila", "Introduceți o categorie validă pentru ustensilă!");
            return "redirect:/modifica-reteta/" + idReteta;
        }

        Ustensila ustensila = ustensilaService.gasesteDupaId(id);
        ustensila.setNume(nume);
        ustensila.setCategorie(categorie);
        ustensilaService.updateUstensila(id, ustensila);

        return "redirect:/modifica-reteta/" + idReteta;
    }

    @GetMapping("/cauta-reteta")
    public String paginaCautareReteta(@ModelAttribute("errorLista") String errorLista,
                                      @ModelAttribute("ingrediente") String ingrediente,
                                      Model model) {
        model.addAttribute("errorLista", errorLista);
        model.addAttribute("ingrediente", ingrediente);
        return "cauta-reteta";
    }

    @PostMapping("/cauta-reteta")
    public String cautaReteta(@RequestParam String ingrediente, Model model, RedirectAttributes redirectAttributes) {

        String regex = "^(\\s*[a-zA-Z ]+\\s*)(,\\s*[a-zA-Z ]+\\s*)*$";

        if (!ingrediente.matches(regex)) {
            redirectAttributes.addFlashAttribute("errorLista", "Introduceți ingredientele separate prin virgulă!");
            redirectAttributes.addFlashAttribute("ingrediente", ingrediente);
            return "redirect:/cauta-reteta";
        }

        List<String> ingredienteCautate = Arrays.stream(ingrediente.split(","))
                .map(String::trim)
                .collect(Collectors.toList());

        List<Reteta> reteteGasite = retetaService.findAll();
        Map<Reteta, Long> reteteCuNumarDeIngrediente = new HashMap<>();

        for (Reteta reteta : reteteGasite) {
            if (reteta.getIngrediente() != null) {
                long numarDeIngredienteComune = reteta.getIngrediente().stream()
                        .filter(ingredient -> ingredienteCautate.contains(ingredient.getNume()))
                        .count();
                if (numarDeIngredienteComune > 0) {
                    reteteCuNumarDeIngrediente.put(reteta, numarDeIngredienteComune);
                }
            }
        }

        List<Reteta> reteteSortate = reteteCuNumarDeIngrediente.entrySet().stream()
                .sorted((entry1, entry2) -> Long.compare(entry2.getValue(), entry1.getValue()))
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        model.addAttribute("retete", reteteSortate);

        return "cauta-reteta";
    }
}



