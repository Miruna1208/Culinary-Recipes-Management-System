package com.retete.retete_culinare.model;

import jakarta.persistence.*;

@Entity
public class Ustensila {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "reteta_id")
    private Reteta reteta;
    private String nume;
    private String categorie;

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public void setReteta(Reteta reteta) {
        this.reteta = reteta;
    }

    public String getNume() {
        return nume;
    }

    public String getCategorie() {
        return categorie;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}
