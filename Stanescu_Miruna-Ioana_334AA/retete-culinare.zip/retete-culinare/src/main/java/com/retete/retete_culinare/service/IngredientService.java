package com.retete.retete_culinare.service;

import com.retete.retete_culinare.model.Ingredient;
import com.retete.retete_culinare.repository.IngredientRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IngredientService {

    @Autowired
    private IngredientRepository ingredientRepository;
    public void salveazaIngredient(Ingredient ingredient) {
        ingredientRepository.save(ingredient);
    }
    public List<Ingredient> gasesteIngredienteDupaRetetaId(Long retetaId) {
        return ingredientRepository.findByRetetaId(retetaId);
    }
    public Ingredient gasesteDupaId(Long id) {
        return ingredientRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Ingredientul cu ID " + id + " nu a fost găsit."));
    }
    public void updateIngredient(Long id, Ingredient ingredientActualizat) {
        Ingredient ingredientExistent = gasesteDupaId(id);

        ingredientExistent.setNume(ingredientActualizat.getNume());
        ingredientExistent.setCategorie(ingredientActualizat.getCategorie());
        ingredientExistent.setCantitate(ingredientActualizat.getCantitate());
        ingredientExistent.setUnitateMasura(ingredientActualizat.getUnitateMasura());

        ingredientRepository.save(ingredientExistent);
    }
}
