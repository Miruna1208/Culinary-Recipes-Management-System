package com.retete.retete_culinare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReteteCulinareApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReteteCulinareApplication.class, args);
	}

}
