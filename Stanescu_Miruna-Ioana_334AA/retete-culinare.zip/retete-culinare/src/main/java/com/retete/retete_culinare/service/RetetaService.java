package com.retete.retete_culinare.service;

import com.retete.retete_culinare.model.Reteta;
import com.retete.retete_culinare.repository.RetetaRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RetetaService {

    @Autowired
    private RetetaRepository retetaRepository;
    @Autowired
    private EntityManager entityManager;

    public Reteta salveazaReteta(Reteta reteta) {
        return retetaRepository.save(reteta);
    }

    public List<Reteta> getAllRetete() {
        return retetaRepository.findAll();
    }

    public Reteta gasesteRetetaDupaId(Long retetaId) {
        return retetaRepository.findById(retetaId).orElse(null);
    }

    public void stergeReteta(Long retetaId) {
        retetaRepository.deleteById(retetaId);
    }

    public void updateReteta(Long id, Reteta reteta) {
        retetaRepository.save(reteta);
    }
    public List<Reteta> findAll() {
        String hql = "FROM Reteta";
        Query query = entityManager.createQuery(hql);
        return query.getResultList();
    }
}

