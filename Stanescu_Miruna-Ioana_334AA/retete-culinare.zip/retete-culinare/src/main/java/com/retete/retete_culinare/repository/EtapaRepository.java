package com.retete.retete_culinare.repository;

import com.retete.retete_culinare.model.Etapa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EtapaRepository extends JpaRepository<Etapa, Long> {
    List<Etapa> findByRetetaId(Long retetaId);
}
