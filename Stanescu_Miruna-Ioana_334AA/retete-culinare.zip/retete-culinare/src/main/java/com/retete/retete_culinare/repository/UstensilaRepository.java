package com.retete.retete_culinare.repository;

import com.retete.retete_culinare.model.Ustensila;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UstensilaRepository extends JpaRepository<Ustensila, Long> {
    List<Ustensila> findByRetetaId(Long retetaId);
}
