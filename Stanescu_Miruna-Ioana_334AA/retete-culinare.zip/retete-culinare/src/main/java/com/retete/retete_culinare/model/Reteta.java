package com.retete.retete_culinare.model;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Reteta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nume;
    private Double cost = 0.0;
    private Integer timpPreparare = 0;
    private String categorie;
    @OneToMany(mappedBy = "reteta", cascade = CascadeType.ALL)
    private List<Ingredient> ingrediente;
    @OneToMany(mappedBy = "reteta", cascade = CascadeType.ALL)
    private List<Etapa> etape;
    @OneToMany(mappedBy = "reteta", cascade = CascadeType.ALL)
    private List<Ustensila> ustensile;

    public Reteta(String nume, String categorie, String imagineUrl) {
        this.nume = nume;
        this.categorie = categorie;
    }
    public Reteta(){}


    public Long getId() {
        return id;
    }
    public String getNume() {
        return nume;
    }
    public String getCategorie() {
        return categorie;
    }
    public Double getCost() {
        return cost;
    }
    public void setCost(Double cost) {
        this.cost = cost;
    }
    public void setTimpPreparare(Integer timpPreparare) {
        this.timpPreparare = timpPreparare;
    }
    public Integer getTimpPreparare() {
        return timpPreparare;
    }
    public void setNume(String nume) {
        this.nume = nume;
    }
    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public List<Ingredient> getIngrediente() {
        return ingrediente;
    }
    public List<Etapa> getEtape() {
        return etape;
    }
    public List<Ustensila> getUstensile() {
        return ustensile;
    }
}
