package com.retete.retete_culinare.repository;

import com.retete.retete_culinare.model.Reteta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RetetaRepository extends JpaRepository<Reteta, Long> {
}