package com.retete.retete_culinare.service;

import com.retete.retete_culinare.model.Ustensila;
import com.retete.retete_culinare.repository.UstensilaRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UstensilaService {

    @Autowired
    private UstensilaRepository ustensilaRepository;

    public void salveazaUstensila(Ustensila ustensila) {
        ustensilaRepository.save(ustensila);
    }

    public List<Ustensila> gasesteUstensileDupaRetetaId(Long retetaId) {
        return ustensilaRepository.findByRetetaId(retetaId);
    }

    public Ustensila gasesteDupaId(Long id) {
        return ustensilaRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Ustensila cu ID " + id + " nu a fost găsită."));
    }

    public void updateUstensila(Long id, Ustensila ustensilaActualizata) {
        Ustensila ustensilaExistenta = gasesteDupaId(id);

        ustensilaExistenta.setNume(ustensilaActualizata.getNume());
        ustensilaExistenta.setCategorie(ustensilaActualizata.getCategorie());

        ustensilaRepository.save(ustensilaExistenta);
    }
}
