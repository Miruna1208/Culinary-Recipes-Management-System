package com.retete.retete_culinare.service;

import com.retete.retete_culinare.model.Etapa;
import com.retete.retete_culinare.repository.EtapaRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EtapaService {

    @Autowired
    private EtapaRepository etapaRepository;

    public void salveazaEtapa(Etapa etapa) {
        etapaRepository.save(etapa);
    }

    public List<Etapa> gasesteEtapeDupaRetetaId(Long retetaId) {
        return etapaRepository.findByRetetaId(retetaId);
    }

    public Etapa gasesteDupaId(Long id) {
        return etapaRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Etapa cu ID " + id + " nu a fost găsită."));
    }

    public void updateEtapa(Long id, Etapa etapaActualizata) {
        Etapa etapaExistenta = gasesteDupaId(id);

        etapaExistenta.setNume(etapaActualizata.getNume());
        etapaExistenta.setTimp(etapaActualizata.getTimp());
        etapaExistenta.setDescriere(etapaActualizata.getDescriere());

        etapaRepository.save(etapaExistenta);
    }
}
